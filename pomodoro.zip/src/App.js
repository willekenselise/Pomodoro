import React from "react";
import Timer from "./Timer";

export default function App() {
  return (
    <div className="App">
      <Timer />
    </div>
  );
}