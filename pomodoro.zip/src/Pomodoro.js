
/*import React, {useState, useEffect} from 'react';


export default function Pomodoro(){

  const [minutes, setMinutes] = useState(2);
  const [seconds, setSeconds] = useState(0);
  const [pause, setPause] = useState(true);
  const [start, setStart] = useState(false);
  
  useEffect(() => {

    if(start){
      console.log("start");
      setStart(false);
      setPause(false);
    };

    if(!pause){
      console.log("run");
      let interval = setInterval(() => {
        clearInterval(interval);

          if(seconds === 0){
            if(minutes !== 0){
              setSeconds(59);
              setMinutes( minutes - 1);
            }
          }else{
            setSeconds(seconds - 1);
          }   
      }, 1000)
    }
  }, [seconds]);


  const timerMinutes = minutes < 10 ? `0${minutes}` : minutes;
  const timerSeconds =  seconds  < 10 ? `0${seconds}` : seconds;

  return (
    <div className="pomodoro">
      <div className="message">
          <h1>Timer</h1>
          <div className="timer">{timerMinutes}:{timerSeconds}</div>
          <button onClick={() => {setPause(true)}}>Pause</button>
          <button onClick={() => {setPause(false)}}>Relancer</button>
          <button onClick={() => {setStart(true)}}>Lancer</button>
          </div>
    </div>
  );
}


import React, { useState, useEffect } from 'react';

export default function Pomodoro() {
  const [minutes, setMinutes] = useState(4);
  const [seconds, setSeconds] = useState(0);
  const [run, setRun] = useState(false); 

  useEffect(() => {
    let interval = setInterval(() => {
      clearInterval(interval);

      if(run){
        if(seconds === 0){
          if(minutes !== 0){
            setSeconds(59);
            setMinutes( minutes - 1);
          }
        }else{
          setSeconds(seconds - 1);
        } 
      }
      
      else{
        setSeconds(seconds);
        setMinutes(minutes);
      }  
    }, 1000);

    return interval;
  });


  const pause = (interval) => {
   setRun(false);
   clearInterval(interval);
   console.log(interval);
  }



  return (
    <div>
      <p>{minutes}:{seconds}</p>
      <button onClick={() => pause(inter)}>Pause</button>
      <button onClick={() => setRun(true)}>Start</button>
    </div>
  );

  };

  */


 